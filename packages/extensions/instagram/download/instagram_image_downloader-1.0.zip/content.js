/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/*!************************!*\
  !*** ./src/content.ts ***!
  \************************/

document.addEventListener('click', (e) => {
    const maxLevels = 3; // Change this number for how far to go up
    let target = e.target;
    let currentLevel = 0;
    console.log('[IG Downloader] Initial clicked element:', target);
    let img = null;
    while (target && currentLevel <= maxLevels) {
        // Check if this element itself is an image
        if (target.tagName.toLowerCase() === 'img') {
            img = target;
            break;
        }
        // Or if it contains an image inside
        const foundImg = target.querySelector('img');
        if (foundImg) {
            img = foundImg;
            break;
        }
        // Go up to parent
        target = target.parentElement;
        currentLevel++;
    }
    if (!img) {
        console.log('[IG Downloader] No <img> element found after traversing upward.');
        return;
    }
    const url = img.src;
    console.log('[IG Downloader] Image URL detected:', url);
    // Send message to background script
    browser.runtime
        .sendMessage({ action: 'download', url })
        .then(() => {
        console.log('[IG Downloader] Message sent to background for download.');
    })
        .catch((err) => {
        console.error('[IG Downloader] Failed to send message:', err);
    });
});

/******/ })()
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29udGVudC5qcyIsIm1hcHBpbmdzIjoiOzs7OztBQUFhO0FBQ2I7QUFDQSx5QkFBeUI7QUFDekI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx1QkFBdUIseUJBQXlCO0FBQ2hEO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBLEtBQUs7QUFDTCxDQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vQGluc3RhZ3JhbS9leHRlbnNpb24vLi9zcmMvY29udGVudC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJcInVzZSBzdHJpY3RcIjtcbmRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKGUpID0+IHtcbiAgICBjb25zdCBtYXhMZXZlbHMgPSAzOyAvLyBDaGFuZ2UgdGhpcyBudW1iZXIgZm9yIGhvdyBmYXIgdG8gZ28gdXBcbiAgICBsZXQgdGFyZ2V0ID0gZS50YXJnZXQ7XG4gICAgbGV0IGN1cnJlbnRMZXZlbCA9IDA7XG4gICAgY29uc29sZS5sb2coJ1tJRyBEb3dubG9hZGVyXSBJbml0aWFsIGNsaWNrZWQgZWxlbWVudDonLCB0YXJnZXQpO1xuICAgIGxldCBpbWcgPSBudWxsO1xuICAgIHdoaWxlICh0YXJnZXQgJiYgY3VycmVudExldmVsIDw9IG1heExldmVscykge1xuICAgICAgICAvLyBDaGVjayBpZiB0aGlzIGVsZW1lbnQgaXRzZWxmIGlzIGFuIGltYWdlXG4gICAgICAgIGlmICh0YXJnZXQudGFnTmFtZS50b0xvd2VyQ2FzZSgpID09PSAnaW1nJykge1xuICAgICAgICAgICAgaW1nID0gdGFyZ2V0O1xuICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgIH1cbiAgICAgICAgLy8gT3IgaWYgaXQgY29udGFpbnMgYW4gaW1hZ2UgaW5zaWRlXG4gICAgICAgIGNvbnN0IGZvdW5kSW1nID0gdGFyZ2V0LnF1ZXJ5U2VsZWN0b3IoJ2ltZycpO1xuICAgICAgICBpZiAoZm91bmRJbWcpIHtcbiAgICAgICAgICAgIGltZyA9IGZvdW5kSW1nO1xuICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgIH1cbiAgICAgICAgLy8gR28gdXAgdG8gcGFyZW50XG4gICAgICAgIHRhcmdldCA9IHRhcmdldC5wYXJlbnRFbGVtZW50O1xuICAgICAgICBjdXJyZW50TGV2ZWwrKztcbiAgICB9XG4gICAgaWYgKCFpbWcpIHtcbiAgICAgICAgY29uc29sZS5sb2coJ1tJRyBEb3dubG9hZGVyXSBObyA8aW1nPiBlbGVtZW50IGZvdW5kIGFmdGVyIHRyYXZlcnNpbmcgdXB3YXJkLicpO1xuICAgICAgICByZXR1cm47XG4gICAgfVxuICAgIGNvbnN0IHVybCA9IGltZy5zcmM7XG4gICAgY29uc29sZS5sb2coJ1tJRyBEb3dubG9hZGVyXSBJbWFnZSBVUkwgZGV0ZWN0ZWQ6JywgdXJsKTtcbiAgICAvLyBTZW5kIG1lc3NhZ2UgdG8gYmFja2dyb3VuZCBzY3JpcHRcbiAgICBicm93c2VyLnJ1bnRpbWVcbiAgICAgICAgLnNlbmRNZXNzYWdlKHsgYWN0aW9uOiAnZG93bmxvYWQnLCB1cmwgfSlcbiAgICAgICAgLnRoZW4oKCkgPT4ge1xuICAgICAgICBjb25zb2xlLmxvZygnW0lHIERvd25sb2FkZXJdIE1lc3NhZ2Ugc2VudCB0byBiYWNrZ3JvdW5kIGZvciBkb3dubG9hZC4nKTtcbiAgICB9KVxuICAgICAgICAuY2F0Y2goKGVycikgPT4ge1xuICAgICAgICBjb25zb2xlLmVycm9yKCdbSUcgRG93bmxvYWRlcl0gRmFpbGVkIHRvIHNlbmQgbWVzc2FnZTonLCBlcnIpO1xuICAgIH0pO1xufSk7XG4iXSwibmFtZXMiOltdLCJzb3VyY2VSb290IjoiIn0=